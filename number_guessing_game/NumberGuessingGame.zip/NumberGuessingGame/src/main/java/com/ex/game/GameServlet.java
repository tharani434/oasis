package com.ex.game;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/game")
public class GameServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
       
        if (session.getAttribute("game") == null) {
            session.setAttribute("game", new NumberGame());
        }
        
        request.getRequestDispatcher("/game.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        NumberGame game = (NumberGame) session.getAttribute("game");
        
        String action = request.getParameter("action");
        
        if ("guess".equals(action)) {
            try {
                int guess = Integer.parseInt(request.getParameter("guess"));
                String result = game.checkGuess(guess);
                request.setAttribute("result", result);
            } catch (NumberFormatException e) {
                request.setAttribute("error", "Please enter a valid number!");
            }
        } else if ("new".equals(action)) {
            game.resetGame();
        }
        
        session.setAttribute("game", game);
        request.getRequestDispatcher("/game.jsp").forward(request, response);
    }
}