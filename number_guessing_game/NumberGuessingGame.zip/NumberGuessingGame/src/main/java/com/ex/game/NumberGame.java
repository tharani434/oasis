package com.ex.game;

import java.util.Random;

public class NumberGame {
    private int targetNumber;
    private int attempts;
    private int maxAttempts = 10;
    private boolean gameWon;
    private int score;

    public NumberGame() {
        resetGame();
    }

    public void resetGame() {
        Random rand = new Random();
        this.targetNumber = rand.nextInt(100) + 1;
        this.attempts = 0;
        this.gameWon = false;
        this.score = 100; 
    }

    public String checkGuess(int guess) {
        attempts++;
        
        if (guess == targetNumber) {
            gameWon = true;
            return "correct";
        } else if (guess < targetNumber) {
            score -= 10;
            return "higher";
        } else {
            score -= 10;
            return "lower";
        }
    }

    
    public int getTargetNumber() { return targetNumber; }
    public int getAttempts() { return attempts; }
    public int getMaxAttempts() { return maxAttempts; }
    public boolean isGameWon() { return gameWon; }
    public int getScore() { return score; }
}